// EXEMPLO

function hello() {
    h1 = document.querySelector('h1')
    h1.innerHTML = 'Hello World!'
}


// EXERCÍCIO 1

function mostra_faixa() {
}


// EXERCÍCIO 2

function mostra_tipo() {
}


// EXERCÍCIO 3

function imprime_tabuada(n) {
}


// EXERCÍCIO 4

function junta() {
}


// EXERCÍCIO 5

function conta() {
}


// DESAFIO

function imprime_arvore(n) {
}
